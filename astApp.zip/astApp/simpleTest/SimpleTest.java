import org.junit.Test;
public class SimpleTest {
	@Test
	public void simpTest(){
		// do nothing
	}
}
