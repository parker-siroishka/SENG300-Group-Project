package astApp;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class TestASTApp {

	// BASE DIRECTORY
	String BASEDIR = "C:\\Users\\Alyssa\\Documents\\Programs\\SENG_300_Group1\\";

		@Test
		public void test_Class() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "InsertionSortDir";   // contains only InsertionSort.java, 1 class
		    
			String[] args = {directory, "InsertionSort"};
				
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "InsertionSort. Declarations found: 1; References found: 0\r\n";
			assertEquals(expected, actual);
			
		}
		
		@Test
		public void test_empty_interface() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "packedJava";
		    
			String[] args = {directory, "EmptyInterface"};
			
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "EmptyInterface. Declarations found: 1; References found: 0\r\n";
			assertEquals(expected, actual);
		}
		
		@Test
		public void test_nonexistent() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "packedJava";   // contains only InsertionSort.java
		    
			String[] args = {directory, "Nonexistent"};
			
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "Nonexistent. Declarations found: 0; References found: 0\r\n";
			assertEquals(expected, actual);
		}

		@Test
		public void test_enum() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "enumDay";   // contains only InsertionSort.java
		    
			String[] args = {directory, "Day"};
			
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "Day. Declarations found: 1; References found: 1\r\n";
			assertEquals(expected, actual);
		}
		
		@Test
		public void test_annotation() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "simpleTest";   // contains only InsertionSort.java
		    
			String[] args = {directory, "Test"};
			
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "Test. Declarations found: 0; References found: 1\r\n";
			assertEquals(expected, actual);
		}
		
		/*
		 * Bug: when a nonexistent directory is used, a NullPointerException is thrown
		 */
		@Test
		public void test_nonexistent_directory() {
			// redirects console output to test
			OutputStream outContent = new ByteArrayOutputStream();
		    System.setOut(new PrintStream(outContent));
		    String directory = BASEDIR + "doesntExist";   // contains only InsertionSort.java
		    
			String[] args = {directory, "NothingHere"};
			
			AppDriver.main(args);
			
			String actual = outContent.toString();
			String expected = "NothingHere. Declarations found: 0; References found: 0\r\n";
			assertEquals(expected, actual);
		}
		
		
}
