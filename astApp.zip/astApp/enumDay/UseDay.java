public class UseDay{
	
	Day day;
	
	public int countDays(){
		int counter = 0;
		for (Day weekday: day){
			counter++;
		}
		return counter;
	}

}