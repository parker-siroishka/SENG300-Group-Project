an invalid .java file

blah blah blah
blaaah  blaaah
blaaaaaaaaaaah

42