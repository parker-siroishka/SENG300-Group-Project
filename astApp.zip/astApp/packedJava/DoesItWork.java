String testClass = "public class DoesItWork{\n"
	private class MaybeWorks{}
	public void add(){ 1 + 1; }
	public void add2(){ add() }
	String a;
	a = \"Hello\";
	int b;
	char c;
	int d;
	Time e;
	enum Quark {UP, DOWN}
}
interface EmptyInterface{}