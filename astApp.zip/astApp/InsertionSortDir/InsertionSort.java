import java.util.ArrayList;
import java.util.Random;
public class InsertionSort{
	
	public static void main(String[] args) {
		
		// Generate list
		ArrayList<Integer> array = new ArrayList<Integer>(10);
		Random generator = new Random();
		for(int i=0;i<10;i++){
			array.add(generator.nextInt(100));
		}
		System.out.println("Original:");
		for(int j=0;j<10;j++){
			System.out.print("  " + array.get(j));
		}
		System.out.print("\nSorting:");
		// Sort list
		int temp;
		for(int h=0;h<10;h++){
			for(int k=h;k>0;k--){
				if (array.get(k-1) > array.get(k)){
					temp = array.get(k-1);
					array.set(k-1, array.get(k));
					array.set(k, temp);
				}
			}
			System.out.println("");
			for(int j=0;j<10;j++){
				System.out.print("  " + array.get(j));
			}
		}
		
		System.out.println("\nFinal:");
		for(int j=0;j<10;j++){
			System.out.print("  " + array.get(j));
		}
		
		// Binary search for num closest to 50 (change to args[0]?)
		int searchNum = Integer.parseInt(args[0]);
		int closestNum = binarySearchUnder(array, 0, 9, searchNum);
		System.out.println("\nClosest number to " + searchNum + " in array:\n" + closestNum);
		}
		
	
	
	static int binarySearchUnder(ArrayList<Integer> list, int startIndex, int endIndex, int value){
		if ((list.get(startIndex) == list.get(endIndex))) {
			if (list.get(startIndex) == value){
				return value;					// found number
			} else {
				return list.get(startIndex);	// return closest number
			}
		} else if (endIndex == (startIndex + 1)){
			int diff1 = value - list.get(startIndex);
			int diff2 = list.get(endIndex) - value;
			if (diff1 < diff2){
				return list.get(startIndex);
			} else if (diff1 > diff2){
				return list.get(endIndex);
			} else {
				System.out.println("\n" + list.get(startIndex) + " and " + list.get(endIndex) + " are equally close to " + value);
				return list.get(startIndex);
			}
		} else {
			int size = endIndex - startIndex + 1;
			int midVal = list.get(startIndex + (size / 2));
			if (midVal > value){
				return binarySearchUnder(list, startIndex, (startIndex + (size / 2)), value);
			} else {
				return binarySearchUnder(list, (startIndex + (size / 2)), endIndex, value);
			}
		}
	}
	
}